const express = require('express');
const router = express.Router();

// Array de produtos INICIALMENTE VAZIO
let products = [];

// GET todos os produtos
router.get('/', (req, res) => {
    res.json(products);
});

// GET produto por ID
router.get('/:id', (req, res) => {
    const product = products.find(p => p.id == req.params.id);
    if (product) {
        res.json(product);
    } else {
        res.status(404).json({ error: 'Produto não encontrado' });
    }
});

// POST criar produto
router.post('/', (req, res) => {
    const { name, category, quantity, minimum, unit, description, price } = req.body;
    
    // Validação
    if (!name || !category || !quantity || !minimum || !unit) {
        return res.status(400).json({ 
            error: 'Nome, categoria, quantidade, mínimo e unidade são obrigatórios' 
        });
    }
    
    if (quantity < 0 || minimum < 0) {
        return res.status(400).json({ 
            error: 'Quantidade e mínimo não podem ser negativos' 
        });
    }
    
    // Criar novo produto
    const newProduct = {
        id: products.length > 0 ? Math.max(...products.map(p => p.id)) + 1 : 1,
        name: name.trim(),
        category: category.trim(),
        quantity: parseFloat(quantity),
        minimum: parseFloat(minimum),
        unit: unit.trim(),
        description: (description || '').trim(),
        price: price ? parseFloat(price) : 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    products.push(newProduct);
    res.status(201).json(newProduct);
});

// PUT atualizar produto
router.put('/:id', (req, res) => {
    const { id } = req.params;
    const { name, category, quantity, minimum, unit, description, price } = req.body;
    
    const index = products.findIndex(p => p.id == id);
    
    if (index === -1) {
        return res.status(404).json({ error: 'Produto não encontrado' });
    }
    
    // Validação
    if ((quantity !== undefined && quantity < 0) || 
        (minimum !== undefined && minimum < 0)) {
        return res.status(400).json({ 
            error: 'Quantidade e mínimo não podem ser negativos' 
        });
    }
    
    // Atualizar produto
    products[index] = {
        ...products[index],
        name: name !== undefined ? name.trim() : products[index].name,
        category: category !== undefined ? category.trim() : products[index].category,
        quantity: quantity !== undefined ? parseFloat(quantity) : products[index].quantity,
        minimum: minimum !== undefined ? parseFloat(minimum) : products[index].minimum,
        unit: unit !== undefined ? unit.trim() : products[index].unit,
        description: description !== undefined ? description.trim() : products[index].description,
        price: price !== undefined ? parseFloat(price) : products[index].price,
        updatedAt: new Date().toISOString()
    };
    
    res.json(products[index]);
});

// DELETE produto
router.delete('/:id', (req, res) => {
    const { id } = req.params;
    const initialLength = products.length;
    
    products = products.filter(p => p.id != id);
    
    if (products.length === initialLength) {
        return res.status(404).json({ error: 'Produto não encontrado' });
    }
    
    res.json({ 
        message: 'Produto deletado com sucesso', 
        id,
        remainingCount: products.length
    });
});

// GET buscar produtos (opcional - para busca no backend)
router.get('/search/:term', (req, res) => {
    const term = req.params.term.toLowerCase();
    const filtered = products.filter(p => 
        p.name.toLowerCase().includes(term) ||
        p.category.toLowerCase().includes(term) ||
        p.description.toLowerCase().includes(term)
    );
    res.json(filtered);
});

module.exports = router;