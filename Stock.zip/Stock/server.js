// server.js
const express = require('express');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3005;

// Importar banco de dados (sem inicializar dados)
const db = require('./database/database.js');

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir arquivos estáticos
app.use(express.static(path.join(__dirname, 'public')));

// Rotas da API
const productsRoutes = require('./routes/products.js');
app.use('/api/products', productsRoutes);

// Rota para resetar banco (opcional)
app.post('/api/reset', (req, res) => {
    db.db.run('DELETE FROM products', (err) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json({ message: 'Estoque resetado com sucesso!' });
        }
    });
});

// Rota para verificar status
app.get('/api/status', (req, res) => {
    db.db.get("SELECT COUNT(*) as count FROM products", (err, row) => {
        if (err) {
            res.json({ status: 'error', message: err.message });
        } else {
            res.json({ 
                status: 'ok', 
                message: 'Banco de dados conectado',
                productsCount: row.count,
                note: 'Estoque começa vazio'
            });
        }
    });
});

// Rota principal
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Iniciar servidor
app.listen(PORT, () => {
    console.log(`Acesse: http://localhost:${PORT}`);
});