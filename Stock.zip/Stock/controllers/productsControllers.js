const db = require('../database/database');

// GET /api/products
const getAllProducts = async (req, res) => {
    try {
        const products = await db.getAllProducts();
        res.json(products);
    } catch (error) {
        console.error('Erro ao buscar produtos:', error);
        res.status(500).json({ error: 'Erro ao buscar produtos' });
    }
};

// GET /api/products/:id
const getProductById = async (req, res) => {
    try {
        const product = await db.getProductById(req.params.id);
        if (product) {
            res.json(product);
        } else {
            res.status(404).json({ error: 'Produto não encontrado' });
        }
    } catch (error) {
        console.error('Erro ao buscar produto:', error);
        res.status(500).json({ error: 'Erro ao buscar produto' });
    }
};

// POST /api/products
const createProduct = async (req, res) => {
    try {
        const { name, price, description } = req.body;
        if (!name || !price) {
            return res.status(400).json({ error: 'Nome e preço são obrigatórios' });
        }

        if (isNaN(price) || parseFloat(price) <= 0) {
            return res.status(400).json({ error: 'Preço deve ser um número positivo' });
        }

        const product = {
            name: name.trim(),
            price: parseFloat(price),
            description: (description || '').trim()
        };

        const newProduct = await db.createProduct(product);
        res.status(201).json(newProduct);
    } catch (error) {
        console.error('Erro ao criar produto:', error);
        res.status(500).json({ error: 'Erro ao criar produto' });
    }
};

// PUT /api/products/:id
const updateProduct = async (req, res) => {
    try {
        const { id } = req.params;
        const { name, price, description } = req.body;

        // Verificar se produto existe
        const existingProduct = await db.getProductById(id);
        if (!existingProduct) {
            return res.status(404).json({ error: 'Produto não encontrado' });
        }

        // Validação
        if (price && (isNaN(price) || parseFloat(price) <= 0)) {
            return res.status(400).json({ error: 'Preço deve ser um número positivo' });
        }

        const product = {
            name: name !== undefined ? name.trim() : existingProduct.name,
            price: price !== undefined ? parseFloat(price) : existingProduct.price,
            description: description !== undefined ? description.trim() : existingProduct.description
        };

        const result = await db.updateProduct(id, product);
        res.json({ id, ...product });
    } catch (error) {
        console.error('Erro ao atualizar produto:', error);
        res.status(500).json({ error: 'Erro ao atualizar produto' });
    }
};

// DELETE /api/products/:id
const deleteProduct = async (req, res) => {
    try {
        const { id } = req.params;

        // Verificar se produto existe
        const existingProduct = await db.getProductById(id);
        if (!existingProduct) {
            return res.status(404).json({ error: 'Produto não encontrado' });
        }

        const result = await db.deleteProduct(id);
        res.json({ 
            message: 'Produto removido com sucesso',
            deletedProduct: existingProduct
        });
    } catch (error) {
        console.error('Erro ao remover produto:', error);
        res.status(500).json({ error: 'Erro ao remover produto' });
    }
};

module.exports = {
    getAllProducts,
    getProductById,
    createProduct,
    updateProduct,
    deleteProduct
};