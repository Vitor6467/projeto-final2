const API_URL = '/api/products';

// Estado da aplicação
let products = [];
let editingId = null;
let currentCategoryFilter = '';
let currentSearch = '';
let searchMode = 'highlight';

// Elementos DOM
const elements = {
    productsTable: document.getElementById('products-tbody'),
    productsCount: document.getElementById('products-count'),
    categoriesContainer: document.getElementById('categories-container'),
    searchInput: document.getElementById('search-input'),
    clearSearchBtn: document.getElementById('clear-search'),
    categoryFilter: document.getElementById('category-filter'),
    sortFilter: document.getElementById('sort-filter'),
    addProductBtn: document.getElementById('add-product-btn'),
    productModal: document.getElementById('product-modal'),
    closeModalBtn: document.getElementById('close-modal'),
    cancelBtn: document.getElementById('cancel-btn'),
    productForm: document.getElementById('product-form'),
    modalTitle: document.getElementById('modal-title'),
    notification: document.getElementById('notification'),
    productId: document.getElementById('product-id'),
    nameInput: document.getElementById('name'),
    categoryInput: document.getElementById('category'),
    quantityInput: document.getElementById('quantity'),
    minimumInput: document.getElementById('minimum'),
    unitInput: document.getElementById('unit'),
    descriptionInput: document.getElementById('description'),
    priceInput: document.getElementById('price')
};

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    loadProducts();
    setupEventListeners();
});

// Configurar event listeners
function setupEventListeners() {
    // Botão adicionar produto
    elements.addProductBtn.addEventListener('click', openAddModal);
    
    // Fechar modal
    elements.closeModalBtn.addEventListener('click', closeModal);
    elements.cancelBtn.addEventListener('click', closeModal);
    
    // Fechar modal ao clicar fora
    elements.productModal.addEventListener('click', (e) => {
        if (e.target === elements.productModal) {
            closeModal();
        }
    });
    
    // Formulário
    elements.productForm.addEventListener('submit', handleFormSubmit);
    
    // Filtros
    elements.searchInput.addEventListener('input', handleSearch);
    elements.clearSearchBtn.addEventListener('click', clearSearch);
    elements.categoryFilter.addEventListener('change', handleCategoryFilter);
    elements.sortFilter.addEventListener('change', handleSort);
    
    // Tecla ESC para limpar busca
    elements.searchInput.addEventListener('keyup', (e) => {
        if (e.key === 'Escape') {
            clearSearch();
        }
    });
}

// Função para atualizar o botão (SEM O CONTADOR - VERSÃO CORRIGIDA)
function updateAddButton() {
    if (!elements.addProductBtn) return;
    
    // SEMPRE mostra apenas "Adicionar Produto" ou "Adicionar Primeiro Produto"
    if (products.length === 0) {
        // Quando não há produtos
        elements.addProductBtn.innerHTML = `
            <i class="fas fa-plus-circle"></i>
            <span>Adicionar Primeiro Produto</span>
        `;
        elements.addProductBtn.classList.add('no-products');
    } else {
        // Quando há produtos (SEM CONTADOR)
        elements.addProductBtn.innerHTML = `
            <i class="fas fa-plus"></i>
            <span>Adicionar Produto</span>
        `;
        elements.addProductBtn.classList.remove('no-products');
    }
}

// Busca inteligente com debounce
let searchTimeout;
function handleSearch(e) {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(() => {
        currentSearch = e.target.value.toLowerCase().trim();
        
        // Mostrar/ocultar botão de limpar
        elements.clearSearchBtn.style.display = currentSearch ? 'block' : 'none';
        
        if (!currentSearch) {
            renderAllProducts();
            updateProductCount();
            return;
        }
        
        const matchingProducts = products.filter(p => 
            p.name.toLowerCase().includes(currentSearch) ||
            p.category.toLowerCase().includes(currentSearch) ||
            (p.description && p.description.toLowerCase().includes(currentSearch))
        );
        
        renderProductsWithHighlight(matchingProducts);
        updateSearchCount(matchingProducts.length);
    }, 300);
}

// Limpar busca
function clearSearch() {
    elements.searchInput.value = '';
    currentSearch = '';
    elements.clearSearchBtn.style.display = 'none';
    renderAllProducts();
    updateProductCount();
}

// Carregar produtos
async function loadProducts() {
    try {
        showLoading(true);
        const response = await fetch(API_URL);
        products = await response.json();
        renderAllProducts();
        updateCategories();
        updateProductCount();
        updateAddButton(); // Atualiza o botão
        showLoading(false);
    } catch (error) {
        showNotification('Erro ao carregar produtos', 'error');
        console.error('Erro:', error);
        showLoading(false);
    }
}

// Mostrar loading
function showLoading(show) {
    if (show) {
        elements.productsTable.innerHTML = `
            <tr class="loading-row">
                <td colspan="6">
                    <div class="loading-spinner">
                        <i class="fas fa-spinner fa-spin"></i>
                        <span>Carregando produtos...</span>
                    </div>
                </td>
            </tr>
        `;
    }
}

// Renderizar todos os produtos (sem busca)
function renderAllProducts() {
    let filteredProducts = [...products];
    
    if (currentCategoryFilter) {
        filteredProducts = filteredProducts.filter(p => 
            p.category.toLowerCase() === currentCategoryFilter.toLowerCase()
        );
    }
    
    const sortBy = elements.sortFilter.value;
    filteredProducts.sort((a, b) => {
        if (sortBy === 'quantity') {
            return b.quantity - a.quantity;
        } else if (sortBy === 'category') {
            return a.category.localeCompare(b.category);
        } else {
            return a.name.localeCompare(b.name);
        }
    });
    
    renderProducts(filteredProducts);
}

// Renderizar produtos com destaque para busca
function renderProductsWithHighlight(matchingProducts) {
    let filteredProducts = [...products];
    
    if (currentCategoryFilter) {
        filteredProducts = filteredProducts.filter(p => 
            p.category.toLowerCase() === currentCategoryFilter.toLowerCase()
        );
    }
    
    const sortBy = elements.sortFilter.value;
    filteredProducts.sort((a, b) => {
        if (sortBy === 'quantity') {
            return b.quantity - a.quantity;
        } else if (sortBy === 'category') {
            return a.category.localeCompare(b.category);
        } else {
            return a.name.localeCompare(b.name);
        }
    });
    
    renderProducts(filteredProducts, matchingProducts);
}

// Função principal de renderização
function renderProducts(productsToRender, matchingProducts = null) {
    if (productsToRender.length === 0) {
        elements.productsTable.innerHTML = `
            <tr>
                <td colspan="6" class="no-products">
                    <div style="text-align: center; padding: 50px 20px;">
                        <i class="fas fa-box-open" style="font-size: 4rem; color: #bdc3c7; margin-bottom: 25px;"></i>
                        <h3 style="color: #2c3e50; margin-bottom: 15px; font-size: 1.8rem;">Seu Estoque Está Vazio</h3>
                        <p style="color: #7f8c8d; margin-bottom: 30px; font-size: 1.1rem; line-height: 1.6;">
                            Nenhum produto cadastrado ainda.<br>
                            Clique no botão verde acima para adicionar seu primeiro produto.
                        </p>
                        
                        <div style="background: #f8f9fa; padding: 25px; border-radius: 12px; max-width: 600px; margin: 0 auto; text-align: left;">
                            <h4 style="color: #2c3e50; margin-bottom: 15px; display: flex; align-items: center; gap: 10px;">
                                <i class="fas fa-lightbulb" style="color: #f39c12;"></i>
                                Como começar:
                            </h4>
                            <ol style="color: #7f8c8d; padding-left: 20px; margin: 0;">
                                <li style="margin-bottom: 10px;">Use o botão <strong>"Adicionar Primeiro Produto"</strong> acima</li>
                                <li style="margin-bottom: 10px;">Preencha nome, categoria, quantidade e outras informações</li>
                                <li style="margin-bottom: 10px;">Organize seus produtos usando as categorias e filtros</li>
                                <li>Use a busca para encontrar produtos rapidamente</li>
                            </ol>
                        </div>
                    </div>
                </td>
            </tr>
        `;
        return;
    }
    
    elements.productsTable.innerHTML = productsToRender.map(product => {
        const isMatch = matchingProducts ? 
            matchingProducts.some(p => p.id === product.id) : true;
        
        const highlightedName = currentSearch && isMatch ? 
            highlightText(product.name, currentSearch) : product.name;
        const highlightedCategory = currentSearch && isMatch ? 
            highlightText(product.category, currentSearch) : product.category;
        
        return `
            <tr class="${isMatch ? 'search-match' : 'search-no-match'} ${product.quantity <= product.minimum ? 'low-stock' : ''}">
                <td class="product-name-cell">
                    <i class="fas fa-box"></i>
                    ${highlightedName}
                    ${currentSearch && !isMatch ? 
                        '<span class="search-notice">(não corresponde à busca)</span>' : ''}
                </td>
                <td class="category-cell">
                    <span class="category-badge">${highlightedCategory}</span>
                </td>
                <td class="quantity-cell ${product.quantity <= product.minimum ? 'low' : 'good'}">
                    ${product.quantity}
                </td>
                <td class="minimum-cell">${product.minimum}</td>
                <td class="unit-cell">
                    <span class="unit-badge">${product.unit}</span>
                </td>
                <td class="actions-cell">
                    <button class="action-button edit-button" onclick="editProduct(${product.id})">
                        <i class="fas fa-edit"></i> Editar
                    </button>
                    <button class="action-button delete-button" onclick="deleteProduct(${product.id})">
                        <i class="fas fa-trash"></i> Excluir
                    </button>
                </td>
            </tr>
        `;
    }).join('');
}

// Destacar texto da busca
function highlightText(text, searchTerm) {
    if (!searchTerm || !text.toLowerCase().includes(searchTerm.toLowerCase())) {
        return text;
    }
    
    const regex = new RegExp(`(${searchTerm})`, 'gi');
    return text.replace(regex, '<span class="highlight">$1</span>');
}

// Atualizar categorias
function updateCategories() {
    const categories = [...new Set(products.map(p => p.category))];
    
    elements.categoriesContainer.innerHTML = categories.map(category => `
        <div class="category-chip ${currentCategoryFilter === category ? 'active' : ''}" 
             onclick="filterByCategory('${category}')">
            ${category}
        </div>
    `).join('');
    
    const allChip = `<div class="category-chip ${!currentCategoryFilter ? 'active' : ''}" 
                       onclick="filterByCategory('')">
                       Todas
                     </div>`;
    elements.categoriesContainer.insertAdjacentHTML('afterbegin', allChip);
}

// Atualizar contador normal
function updateProductCount() {
    let filteredCount = products.length;
    
    if (currentCategoryFilter) {
        filteredCount = products.filter(p => p.category === currentCategoryFilter).length;
    }
    
    elements.productsCount.innerHTML = `
        <span class="count-badge">${filteredCount}</span>
        <span class="count-text">${filteredCount === 1 ? 'produto' : 'produtos'}</span>
    `;
}

// Atualizar contador de busca
function updateSearchCount(matchCount) {
    let filteredCount = products.length;
    
    if (currentCategoryFilter) {
        filteredCount = products.filter(p => p.category === currentCategoryFilter).length;
    }
    
    elements.productsCount.innerHTML = `
        <span class="count-badge">${matchCount}</span>
        <span class="count-text">de ${filteredCount} produtos encontrados</span>
        <span class="search-term">para "${currentSearch}"</span>
    `;
}

// Filtro por categoria
function filterByCategory(category) {
    currentCategoryFilter = category;
    elements.categoryFilter.value = category;
    
    if (currentSearch) {
        const matchingProducts = products.filter(p => 
            (p.category.toLowerCase() === category.toLowerCase() || !category) &&
            (p.name.toLowerCase().includes(currentSearch) ||
             p.category.toLowerCase().includes(currentSearch) ||
             (p.description && p.description.toLowerCase().includes(currentSearch)))
        );
        renderProductsWithHighlight(matchingProducts);
        updateSearchCount(matchingProducts.length);
    } else {
        renderAllProducts();
        updateProductCount();
    }
    updateCategories();
}

// Filtro de categoria via dropdown
function handleCategoryFilter(e) {
    filterByCategory(e.target.value);
}

// Ordenação
function handleSort() {
    if (currentSearch) {
        const matchingProducts = products.filter(p => 
            p.name.toLowerCase().includes(currentSearch) ||
            p.category.toLowerCase().includes(currentSearch) ||
            (p.description && p.description.toLowerCase().includes(currentSearch))
        );
        renderProductsWithHighlight(matchingProducts);
    } else {
        renderAllProducts();
    }
}

// Abrir modal para adicionar
function openAddModal() {
    editingId = null;
    elements.modalTitle.innerHTML = '<i class="fas fa-plus-circle"></i> Adicionar Produto';
    elements.productForm.reset();
    elements.productId.value = '';
    elements.productModal.classList.add('show');
    
    setTimeout(() => {
        elements.nameInput.focus();
    }, 100);
}

// Abrir modal para editar
async function editProduct(id) {
    try {
        const response = await fetch(`${API_URL}/${id}`);
        const product = await response.json();
        
        editingId = id;
        elements.modalTitle.innerHTML = '<i class="fas fa-edit"></i> Editar Produto';
        elements.productId.value = id;
        elements.nameInput.value = product.name;
        elements.categoryInput.value = product.category;
        elements.quantityInput.value = product.quantity;
        elements.minimumInput.value = product.minimum;
        elements.unitInput.value = product.unit;
        elements.descriptionInput.value = product.description || '';
        elements.priceInput.value = product.price || '';
        
        elements.productModal.classList.add('show');
        
        setTimeout(() => {
            elements.nameInput.focus();
        }, 100);
    } catch (error) {
        showNotification('Erro ao carregar produto', 'error');
    }
}

// Fechar modal
function closeModal() {
    elements.productModal.classList.remove('show');
    editingId = null;
    elements.productForm.reset();
}

// Manipular envio do formulário
async function handleFormSubmit(e) {
    e.preventDefault();
    
    const productData = {
        name: elements.nameInput.value.trim(),
        category: elements.categoryInput.value,
        quantity: parseFloat(elements.quantityInput.value),
        minimum: parseFloat(elements.minimumInput.value),
        unit: elements.unitInput.value,
        description: elements.descriptionInput.value.trim(),
        price: elements.priceInput.value ? parseFloat(elements.priceInput.value) : 0
    };
    
    if (!productData.name || !productData.category || 
        isNaN(productData.quantity) || isNaN(productData.minimum) || !productData.unit) {
        showNotification('Preencha todos os campos obrigatórios', 'error');
        return;
    }
    
    if (productData.quantity < 0 || productData.minimum < 0) {
        showNotification('Quantidade e mínimo não podem ser negativos', 'error');
        return;
    }
    
    try {
        let response;
        
        if (editingId) {
            response = await fetch(`${API_URL}/${editingId}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(productData)
            });
        } else {
            response = await fetch(API_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(productData)
            });
        }
        
        if (response.ok) {
            showNotification(
                editingId ? 'Produto atualizado com sucesso!' : 'Produto criado com sucesso!',
                'success'
            );
            closeModal();
            await loadProducts();
        } else {
            const error = await response.json();
            showNotification(error.error || 'Erro ao salvar produto', 'error');
        }
    } catch (error) {
        showNotification('Erro de conexão', 'error');
        console.error('Erro:', error);
    }
}

// Deletar produto
async function deleteProduct(id) {
    if (!confirm('Tem certeza que deseja excluir este produto?')) return;
    
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            showNotification('Produto excluído com sucesso!', 'success');
            await loadProducts();
        } else {
            const error = await response.json();
            showNotification(error.error || 'Erro ao excluir produto', 'error');
        }
    } catch (error) {
        showNotification('Erro de conexão', 'error');
    }
}

// Mostrar notificação
function showNotification(message, type = 'info') {
    elements.notification.textContent = message;
    elements.notification.className = `notification-toast show ${type}`;
    
    setTimeout(() => {
        elements.notification.classList.remove('show');
    }, 3000);
}


function monitorAndFixButton() {
    const addBtn = document.getElementById('add-product-btn');
    if (!addBtn) return;
    

    const text = addBtn.textContent || addBtn.innerText;
    if (/\d/.test(text)) {
       
        const cleanText = text.replace(/\d+/g, '').replace(/\s+/g, ' ').trim();
        
       
        let finalText = 'Adicionar Produto';
        if (cleanText.includes('Primeiro')) {
            finalText = 'Adicionar Primeiro Produto';
        }
        
       
        addBtn.innerHTML = `
            <i class="fas fa-plus"></i>
            <span>${finalText}</span>
        `;
        console.log('✅ Contador removido do botão');
    }
}


setInterval(monitorAndFixButton, 1000);

document.addEventListener('DOMContentLoaded', function() {
    setTimeout(monitorAndFixButton, 100);
    setTimeout(monitorAndFixButton, 500);
    setTimeout(monitorAndFixButton, 1000);
});


const addBtn = document.getElementById('add-product-btn');
if (addBtn) {
    const observer = new MutationObserver(monitorAndFixButton);
    observer.observe(addBtn, {
        childList: true,
        characterData: true,
        subtree: true
    });
}


const originalUpdateAddButton = window.updateAddButton;
if (originalUpdateAddButton) {
    window.updateAddButton = function() {
        const result = originalUpdateAddButton();
       
        setTimeout(monitorAndFixButton, 50);
        return result;
    };
}


window.editProduct = editProduct;
window.deleteProduct = deleteProduct;
window.filterByCategory = filterByCategory;
window.clearSearch = clearSearch;
window.openAddModal = openAddModal;